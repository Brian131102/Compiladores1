#mi primer analizador lexico que solo me reconocer 
# numeros enteros, identificadores, operadores
# librerias: lexico, re

import re

#crear tokens
token_patterns = [
('Numeros',      r'\d+(\.\d*)?'),      
('IF',          r'\bif\b'),               
('ELSE',        r'\belse\b'),          
('WHILE',       r'\bwhile\b'),          
('RETURN',      r'\breturn\b'),       
('FUNCTION',    r'\bfunction\b'),       
('VAR',         r'\bvar\b'),            
('CONST',       r'\bconst\b'),            
('TRUE',        r'\btrue\b'),          
('FALSE',       r'\bfalse\b'),             
('NULL',        r'\bnull\b'),              
('Identificadores',          r'[A-Za-z_]\w*'),     
('Asignación',      r'='),                  
('Suma',        r'\+'),                 
('Resta',       r'-'),                     
('Multiplicación',        r'\*'),   
('División',         r'/'),               
('Porcentaje',         r'%'),                 
('Menor_que',          r'<'),              
('Mayor_que',          r'>'),                    
('Diferente_De',          r'!='),                 
('AND',         r'&&'),               
('OR',          r'\|\|'),             
('NOT',         r'!'),                 
('PARENTESIS_IZQ',      r'\('),           
('PARENTESIS_DER',      r'\)'),             
('LLave_IZQ',      r'\{'),               
('LLave_DER',      r'\}'),                
('Corchete_IZQ',    r'\['),                   
('Corchete_DER',    r'\]'),                  
('Punto_y_coma',        r';'),                     
('Dos_Puntos',       r':'),           
('Coma',       r','),                     
('Punto',         r'\.'),                 
('CHAR',        r'\'[^\'\\]*(?:\\.[^\'\\]*)*\''), 
('Linea_Nueva',     r'\n'),                  
('Espacio',        r'[ \t]+'),             
('FOR',         r'\bfor\b'),            
('DOLAR',      r'\$'),                    
('Signo_de_Numero',        r'#'),                     
('Ampersand',         r'&'),                     
('Signo_de_interrogación',    r'\?'),                   
('Exclamacion_Invertido', r'¡'),                    
('comillas_simples',       r'\'|\"'),               
('Interrogación_Invertido', r'¿'),           
('TILDE',       r'~'),                     
('Acento_grave',    r'`'),                     
('Circunflejo',       r'\^'),                  
('Arroba',          r'@'),                
('Negación',         r'¬'),                     
('Grado',      r'°'),                  
('MISMATCH',    r'.'),                    
]


token_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in token_patterns)
get_token = re.compile(token_regex).match

def tokenize(code):
    line_number = 1
    line_start = 0
    position = 0
    tokens = []
    counter = 1

    while position < len(code):
        match = get_token(code, position)
        if not match:
            raise RuntimeError(f'Error de Analisis en posicion {position}')
        
        for name, value in match.groupdict().items():
            if value:
                if name != 'ESPACIO':
                    tokens.append((counter, name, value))
                    counter = 1+counter
                break
        position = match.end()

    return tokens  



code = "1I=+-*/%<>!=&&||!(){}[];:,.'hola'\n$#&?¡'¿~`^@¬°if else while return function var const true false null"  
tokens = tokenize(code)
for token in tokens:
    print(token)

    